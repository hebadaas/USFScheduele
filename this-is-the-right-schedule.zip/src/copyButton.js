export function copyCRN(crnNum) {
  /* Get the text field */

  /* Copy the text inside the text field */
  navigator.clipboard.writeText(crnNum);

  /* Alert the copied text */
  alert("Copied the text: " + crnNum);
}
