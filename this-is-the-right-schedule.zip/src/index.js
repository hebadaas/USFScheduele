import "./styles.css";
import {
  showSuggestions,
  classSelected,
  notSelected,
  filterFunction,
  changeOptions
} from "./searchBar.js";
import { changeDetails } from "./sectionSelec";
import { copyCRN } from "./copyButton.js";

var search = document.getElementById("mySearch");

search.addEventListener("click", () => showSuggestions());

search.addEventListener("keyup", (event) => {
  if (event.key === "Enter") {
    // Cancel the default action, if needed
    event.preventDefault();
    // Trigger the button element with a click
    document.getElementById("search-enter").click();
    notSelected();
  }
});

window.classSelected = (num) => {
  classSelected(num);
};
window.notSelected = () => {
  notSelected();
};
window.filterFunction = (num) => {
  filterFunction();
};
window.changeOptions = () => {
  changeOptions();
};
window.changeSection = (num1, num2) => {
  changeDetails(num1, num2);
};
window.copyCRN = (num) => {
  copyCRN(num);
};
