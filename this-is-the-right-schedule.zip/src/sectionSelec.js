import { courses } from "./courseData.js";
export function changeDetails(num1, num2) {
  let currentSection = courses[num1].sections[num2];
  document.getElementsByClassName("details")[0].innerHTML =
    `<i><b> Course: </b> ` +
    courses[num1].name +
    "-" +
    currentSection.number +
    `<p> 
  <b> Professor: </b>` +
    currentSection.prof +
    `<P> 
  <b> Date/Time:</B> M/W 9:30-10:45 AM <p> 
  <B> Campus: </B>` +
    currentSection.campus +
    `<p>
  <B> Class Type: </B>` +
    currentSection.classType +
    `<p>
  <B> Dates: </B>` +
    currentSection.dates +
    `<p>
  <B> CRN:` +
    currentSection.crn +
    `</B> <button onclick="copyCRN(` +
    currentSection.crn +
    `)">📋</button>  <p> 
   </i>`;
  document.getElementsByClassName("class-block")[0].innerHTML =
    courses[num1].name + "-" + currentSection.number;
  document.getElementsByClassName("class-block")[1].innerHTML =
    courses[num1].name + "-" + currentSection.number;
}
