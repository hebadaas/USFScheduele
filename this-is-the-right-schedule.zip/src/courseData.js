export let courses = [
  {
    name: "IDH 2400: Ethics",
    sections: [
      {
        number: "001",
        prof: "Reginald Lucien",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      },
      {
        number: "002",
        prof: "Sheldon Cooper",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "5678"
      },
      {
        number: "003",
        prof: "John Keating",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      }
    ]
  },
  {
    name: "MAC 2311: Calculus 1",
    sections: [
      {
        number: "001",
        prof: "Reginald Lucien",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      },
      {
        number: "002",
        prof: "Sheldon Cooper",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      },
      {
        number: "003",
        prof: "John Keating",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      }
    ]
  },
  {
    name: "BSC 2010: Biology",
    sections: [
      {
        number: "001",
        prof: "Reginald Lucien",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      },
      {
        number: "002",
        prof: "Sheldon Cooper",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      },
      {
        number: "003",
        prof: "John Keating",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      }
    ]
  },
  {
    name: "PHY 2048: Physics",
    sections: [
      {
        number: "001",
        prof: "Reginald Lucien",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      },
      {
        number: "002",
        prof: "Sheldon Cooper",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      },
      {
        number: "003",
        prof: "John Keating",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      }
    ]
  },
  {
    name: "IDH 3400: Social Science",
    sections: [
      {
        number: "001",
        prof: "Reginald Lucien",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      },
      {
        number: "002",
        prof: "Sheldon Cooper",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      },
      {
        number: "003",
        prof: "John Keating",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      }
    ]
  },
  {
    name: "IDH 2010: Acquisition",
    sections: [
      {
        number: "001",
        prof: "Reginald Lucien",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      },
      {
        number: "002",
        prof: "Sheldon Cooper",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      },
      {
        number: "003",
        prof: "John Keating",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      }
    ]
  },
  {
    name: "IDH 4970: Honors Thesis",
    sections: [
      {
        number: "001",
        prof: "Reginald Lucien",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      },
      {
        number: "002",
        prof: "Sheldon Cooper",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      },
      {
        number: "003",
        prof: "John Keating",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      }
    ]
  },
  {
    name: "IDH 3100: Arts and Humanities",
    sections: [
      {
        number: "001",
        prof: "Reginald Lucien",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      },
      {
        number: "002",
        prof: "Sheldon Cooper",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      },
      {
        number: "003",
        prof: "John Keating",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      }
    ]
  },
  {
    name: "IDH 4200: Geographical Perspectives",
    sections: [
      {
        number: "001",
        prof: "Reginald Lucien",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      },
      {
        number: "002",
        prof: "Sheldon Cooper",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      },
      {
        number: "003",
        prof: "John Keating",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      }
    ]
  },
  {
    name: "IDH 4950: Honors Capstone",
    sections: [
      {
        number: "001",
        prof: "Reginald Lucien",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      },
      {
        number: "002",
        prof: "Sheldon Cooper",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      },
      {
        number: "003",
        prof: "John Keating",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      }
    ]
  },
  {
    name: "CHM 2045: Chemistry 1",
    sections: [
      {
        number: "001",
        prof: "Reginald Lucien",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      },
      {
        number: "002",
        prof: "Sheldon Cooper",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      },
      {
        number: "003",
        prof: "John Keating",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      }
    ]
  },
  {
    name: "BSC 2093C: Anatomy 1",
    sections: [
      {
        number: "001",
        prof: "Reginald Lucien",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      },
      {
        number: "002",
        prof: "Sheldon Cooper",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      },
      {
        number: "003",
        prof: "John Keating",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      }
    ]
  },
  {
    name: "EIN 4243: Human Factors",
    sections: [
      {
        number: "001",
        prof: "Reginald Lucien",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      },
      {
        number: "002",
        prof: "Sheldon Cooper",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      },
      {
        number: "003",
        prof: "John Keating",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      }
    ]
  },
  {
    name: "SOP 4004: Social Psychology",
    sections: [
      {
        number: "001",
        prof: "Reginald Lucien",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      },
      {
        number: "002",
        prof: "Sheldon Cooper",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      },
      {
        number: "003",
        prof: "John Keating",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      }
    ]
  },
  {
    name: "INP 4004: Industrial Psychology",
    sections: [
      {
        number: "001",
        prof: "Reginald Lucien",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      },
      {
        number: "002",
        prof: "Sheldon Cooper",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      },
      {
        number: "003",
        prof: "John Keating",
        campus: "Tampa",
        classType: "Lecture",
        dates: "Jan 10, 2022-May 5, 2022",
        crn: "12345"
      }
    ]
  }
];
