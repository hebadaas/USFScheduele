import { courses } from "./courseData.js";
let currentInput = null;
export function showSuggestions() {
  let suggestions = document.getElementById("suggestions");
  suggestions.innerHTML =
    `<ul id="myMenu">` +
    courses
      .map(function (courses, index) {
        return (
          '<li><a onclick="classSelected(' +
          index +
          ');return false;">' +
          courses.name +
          "</a></li>"
        );
      })
      .join("") +
    `</ul>`;
}
export function classSelected(num) {
  let ul = document.getElementById("myMenu");
  let li = ul.getElementsByTagName("li");
  let a = li[num].getElementsByTagName("a")[0];
  document.getElementById("mySearch").value = a.innerHTML;
  currentInput = num;
  notSelected();
}
export function notSelected() {
  let ul = document.getElementById("myMenu");
  ul.style.display = "none";
}
export function filterFunction() {
  // Declare variables
  var input, filter, ul, li, a, i;
  input = document.getElementById("mySearch");
  if (true) {
    filter = input.value.toUpperCase();
    ul = document.getElementById("myMenu");
    li = ul.getElementsByTagName("li");

    // Loop through all list items, and hide those who don't match the search query
    for (i = 0; i < li.length; i++) {
      a = li[i].getElementsByTagName("a")[0];
      if (a.innerHTML.toUpperCase().indexOf(filter) > -1) {
        li[i].style.display = "block";
      } else {
        li[i].style.display = "none";
      }
    }
  }
}
export function changeOptions() {
  let currentCourse = courses[currentInput];
  let sections = courses[currentInput].sections;
  document.getElementsByClassName("results")[0].innerHTML =
    `<ul id="optionsMenu">` +
    sections
      .map(function (sections, index) {
        return (
          '<li><a onclick="changeSection(' +
          currentInput +
          "," +
          index +
          ')">' +
          currentCourse.name +
          "-" +
          sections.number +
          "</a></li>"
        );
      })
      .join("") +
    `</ul>`;
}
